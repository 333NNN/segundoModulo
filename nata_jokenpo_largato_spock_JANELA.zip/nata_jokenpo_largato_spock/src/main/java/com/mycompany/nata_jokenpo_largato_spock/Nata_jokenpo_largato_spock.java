/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.nata_jokenpo_largato_spock;

import javax.swing.JOptionPane;

public class Nata_jokenpo_largato_spock {

    public static final String[] OPCOES = {"Pedra", "Papel", "Tesoura", "Lagarto", "Spock"};

    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null, "Bem vindo ao JoKenPo\n*---------------------------->REGRAS<-----------------------------*\nEscolha entre Pedra, Papel, Tesoura, Lagarto ou Spock.\nPedra vence tesoura e lagarto, mas perde para o papel e Spock.\nPapel vence pedra e Spock, mas perde para tesoura e lagarto.\nTesoura vence papel e lagarto, mas perde para pedra e Spock.\nLagarto vence papel e Spock, mas perde para pedra e tesoura.\nSpock vence pedra e tesoura, mas perde para papel e lagarto.");
        JOptionPane.showMessageDialog(null, "*---------------------------->JOGO<-----------------------------*");
       
        boolean jogarNovamente = true;
        while (jogarNovamente) {
            jogar();

            jogarNovamente = JOptionPane.showInputDialog("Deseja jogar novamente? (S/N)").equalsIgnoreCase("s");
        }

        JOptionPane.showMessageDialog(null, "Obrigado por jogar! Até mais.");
    }

    public static void jogar() {
    String jogadorUm = obterEscolha("Jogador Um");
    String jogadorDois = obterEscolha("Jogador Dois");

    JOptionPane.showMessageDialog(null, "Jogador Um escolheu: " + jogadorUm);
    JOptionPane.showMessageDialog(null, "Jogador Dois escolheu: " + jogadorDois);

    determinarVencedor(jogadorUm, jogadorDois);
}

    public static String obterEscolha(String jogador) {
        String escolha;
        boolean escolhaValida;

        do {
            escolha = JOptionPane.showInputDialog(jogador + ", escolha: Pedra, Papel, Tesoura, Lagarto ou Spock:").toLowerCase(); // Convertendo para minúsculas
            escolhaValida = validaEscolha(escolha);
        if (!escolhaValida) {
            JOptionPane.showMessageDialog(null, "Escolha inválida. Por favor, tente novamente.");
        }
        } while (!escolhaValida);

        return escolha;
}

    public static String obterEscolha() {
        String escolha;
        boolean escolhaValida;

        do {
            escolha = JOptionPane.showInputDialog("Escolha Pedra, Papel, Tesoura, Lagarto ou Spock:").toLowerCase(); // Convertendo para minúsculas
            escolhaValida = validaEscolha(escolha);
            if (!escolhaValida) {
                JOptionPane.showMessageDialog(null, "Escolha inválida. Por favor, tente novamente.");
            }
        } while (!escolhaValida);

        return escolha;
    }

    public static boolean validaEscolha(String escolha) {
        for (String opcao : OPCOES) {
            if (opcao.equalsIgnoreCase(escolha)) {
                return true;
            }
        }
        return false;
    }

    public static void determinarVencedor(String jogadorUm, String jogadorDois) {
        if (jogadorUm.equalsIgnoreCase(jogadorDois)) {
            JOptionPane.showMessageDialog(null, "Empate!");
        } else if ((jogadorUmVence(jogadorUm, jogadorDois))) {
            JOptionPane.showMessageDialog(null, "Jogador Um venceu!");
        } else {
            JOptionPane.showMessageDialog(null, "Jogador Dois vence!");
        }
    }

    public static boolean jogadorUmVence(String jogadorUm, String jogadorDois) {
    return (jogadorUm.equalsIgnoreCase("Pedra") && (jogadorDois.equalsIgnoreCase("Tesoura") || jogadorDois.equalsIgnoreCase("Lagarto"))) ||
            (jogadorUm.equalsIgnoreCase("Papel") && (jogadorDois.equalsIgnoreCase("Pedra") || jogadorDois.equalsIgnoreCase("Spock"))) ||
            (jogadorUm.equalsIgnoreCase("Tesoura") && (jogadorDois.equalsIgnoreCase("Papel") || jogadorDois.equalsIgnoreCase("Lagarto"))) ||
            (jogadorUm.equalsIgnoreCase("Lagarto") && (jogadorDois.equalsIgnoreCase("Papel") || jogadorDois.equalsIgnoreCase("Spock"))) ||
            (jogadorUm.equalsIgnoreCase("Spock") && (jogadorDois.equalsIgnoreCase("Pedra") || jogadorDois.equalsIgnoreCase("Tesoura")));
    }

}


        
    
    

