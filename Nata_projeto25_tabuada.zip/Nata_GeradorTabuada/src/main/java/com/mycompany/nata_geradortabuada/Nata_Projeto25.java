/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.nata_geradortabuada;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;
import java.util.Date;
/**
 *
 * @author ncunha
 */
public class Nata_Projeto25 {


    public static void main(String[] args) throws IOException {
        Scanner ler = new Scanner(System.in);
        int valorUsuario = 0;
        String nomeArquivo = " ";
        Date data = new Date();
        
        tabuada(nomeArquivo, ler, valorUsuario, data);
        }
    
        static void tabuada(String nomeArquivo, Scanner ler, int valorUsuario, Date data) throws IOException{
            System.out.println("*____TABUADA____*");
            System.out.println("Informe o nome e o caminho completo do arquivo onde deseja salvar o arquivo: ");
            nomeArquivo = ler.next();
            
            System.out.println("Informe um valor: ");
            valorUsuario = ler.nextInt();
            ler.nextLine();
            FileWriter arquivo = new FileWriter(nomeArquivo); 
            PrintWriter escrever = new PrintWriter(arquivo);
            escrever.println("Tabuada do " + valorUsuario + " | " + data + "\n");
            escrever.println("*_______________*");
            for (int i = 1; i < 10; i++){
                escrever.println(i + " x " + valorUsuario + " = " + (i * valorUsuario));
                
            }
            arquivo.close();
        }
   
}
